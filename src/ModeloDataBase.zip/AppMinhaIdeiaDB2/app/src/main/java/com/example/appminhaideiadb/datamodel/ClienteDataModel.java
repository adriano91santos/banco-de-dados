package com.example.appminhaideiadb.datamodel;

public class ClienteDataModel {
}
