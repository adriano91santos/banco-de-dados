package com.example.appminhaideiadb.datamodel;

public class ProdutoDataModel {
}
